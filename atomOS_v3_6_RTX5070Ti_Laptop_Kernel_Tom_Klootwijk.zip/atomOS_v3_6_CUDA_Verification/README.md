# atomOS v3.6 — CUDA kernel and verification package K1

**Concept author: Tom Klootwijk · NL200678942 · 10-07-1990**  
**Target: NVIDIA GeForce RTX 5070 Ti Laptop GPU, 12 GB GDDR7, `sm_120`.**

This package implements the **integrated v3.6 word-epoch profile**, not just the
OTAN2 panel: word production, ASA/NA/fringe selection, whole-word disposition,
persistent J–K state, encoded blend, literal OTAN2, its explicitly selected directed
completion, and the six invariant/profile checks. Two native CUDA entry points use
texture reads or global reads over the same log-polar word dictionaries.

The ZIP provides **kernel source and build tools**, not an installed driver or an
untested precompiled binary. The CPU implementation and specification proofs have
been executed; CUDA compilation and execution require the laptop validation below.

## What the evidence establishes

`proofs/CLAIMS.md` states each claim and its domain. Fifteen SMT-LIB obligations were
checked with Z3; every negated property was **UNSAT**. These include full 32-bit
population-count correctness, neutral-mask recovery, support containment, final-word
idempotence, the J–K truth table, blend parity and the Morton-tile inverse.

Those are symbolic properties of the specified equations, **not a formal verification
of the compiler or GPU machine code**. The concrete implementation is checked with
independent per-bit and Python references. GPU results are accepted only after real
CUDA execution and comparison, never by substituting a CPU run. This establishes
specified software-conformance claims, not every application claim in the transcripts.

**Executed during preparation:** 30 C++ groups / 134,503 assertions; 20 Python unit
tests; seven CPU CTest cases and the same seven under AddressSanitizer + UBSan;
15 symbolic obligations; and 48 full independently checked CPU run configurations.
Exact status and logs are in `results/validation_status.json` and adjacent files.

**Pending:** CUDA compilation, RTX execution, Compute Sanitizer and Windows compilation.
The preparation environment had no nvcc, NVIDIA device or driver. No GPU timings are
presented as measured results in this delivery.

## Run on your laptop

Install a CUDA Toolkit **12.8 or newer**, a CUDA-supported host C++ compiler, CMake
3.24+ and Python 3.10+. Use a compatible installed NVIDIA driver. On Windows, open
the supported x64 compiler developer prompt with `nvcc` on PATH. The hardware/source
references are in `docs/hardware_sources.json`.

From the extracted directory:

```sh
python tools/validate.py --gpu --sanitizer
```

This builds the real CUDA target, records the actual device name/capability/VRAM,
runs CPU/Python checks, then verifies **96 GPU configurations** and four additional
Compute Sanitizer memcheck runs. It covers both layouts, both read paths, all four
word producers, fringe on/off, angular tails and tiny dimensions. Each ordinary run
has three epochs and includes both literal and directed OTAN2 lanes.

To repeat the symbolic proofs too, make Z3 available and add `--proofs`:

```sh
python -m pip install -r requirements-proof.txt
python tools/validate.py --gpu --sanitizer --proofs
```

The proof dependency is optional for the engine. No script installs drivers, changes
privileges or alters a display watchdog. Each review uses a unique evidence directory
and keeps command logs. Missing GPU tools return code 3 and an explicit `not_run`
record; a failed comparison returns an error, not a success certificate.

### Manual build

```sh
cmake -S . -B build_gpu -DATOMOS_ENABLE_CUDA=ON -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_ARCHITECTURES="120-real;120-virtual"
cmake --build build_gpu --config Release --parallel 2
```

Linux:

```sh
./build_gpu/atomos_cuda --probe
./build_gpu/atomos_cuda --out my_gpu_run
python tools/verify_run.py my_gpu_run
```

Windows with a multi-configuration generator:

```powershell
.\build_gpu\Release\atomos_cuda.exe --probe
.\build_gpu\Release\atomos_cuda.exe --out my_gpu_run
python tools/verify_run.py my_gpu_run
```

`my_gpu_run` must not already exist. Single-configuration Windows generators may put
the executable directly under `build_gpu`; the validation script resolves both forms.

## Implemented epoch

For each logical lane, read its immutable aperture dictionary and pre-epoch state:

```text
provided / recurrent / shift-XOR / shift-OR word producer
    -> ASA & valid & optional fringe
    -> NA
    -> POPCNT(selected & boundary)
    -> output = 0 on ANY intersection, otherwise selected

same frozen epoch:
    JK(q,j,k) -> next q
    north_bit XOR axis_bit XOR kinematic_bit -> encoded blend (when defined)
    OTAN2(delta_phase, delta_rho) - supplied_axis -> typed angle record
    R / W / P / S / F / V -> named comparison records

verify every proposed lane -> commit host word and JK banks together
```

One boundary intersection zeros the **whole selected 32-bit word**, not merely the
intersecting bit. An undefined OTAN2 record does not become a false numerical zero,
a new aperture mask, or an automatic J/K input. J/K is an explicit bit bank, one
stored bit per logical lane in K1. A bad required input or mismatch prevents commit.

The source ratio `atan(delta_phase / delta_rho)` is retained, including its zero-
denominator status. `directed_completion_1` is named separately. The GPU uses double
precision for these diagnostics and disables fused multiply-add contraction in the
build. No fast-math flag is enabled.

## Texture and laptop memory contract

The log-polar dictionary uses r_min=0.25, r_max=64, radial cell centers and periodic
angular nodes. `include/atomos/log_polar.hpp` provides the host coordinate compiler.
The GPU consumes exact packed predicates from this dictionary, not native code in
a texture cache. Texture residency remains hardware-managed.

Four immutable uint32 mask buffers are exposed through `cudaTextureObject_t` and
read with `tex1Dfetch<unsigned int>`. Linear and 8×8 word-Morton layouts have the same
logical output order; radial bits occupy even Morton positions. Live state, lane
inputs and result buffers are separate global-memory resources.

The default 128×1024-cell case has 4,096 logical word lanes and **1,114,112 bytes of
device payload**, plus a 64 MiB planning margin. The default ceiling is 512 MiB,
with a 1,536 MiB device reserve and a limit of 70% of currently free VRAM. The driver’s
reported byte counts govern admission; advertised 12 GB is not assumed to be free.

GPU `compute_ms` records kernel time only, excluding upload, download, CPU checking
and file output. CPU `compute_ms` covers CPU proposal creation, including its output
allocation. They are not matched end-to-end performance measurements.

## Scope within the total engine

K1 is a concrete implementation of the master **word-epoch** producer contract,
including both provided and recurrent words and the two literal shift variants.
Identity/genesis and retained-reference SHA-256 seals run on the host.

The master’s optional RK4/field producer, continuous lens function, capsule-to-cell
compiler, Klein-surface dynamics and programmable tape interpreter are not CUDA
backends in this package. `docs/coverage.csv` identifies those ports explicitly.
There is no implicit sensor feed, person-matching input, external trigger, privileged
loader or device-actuation interface. The supplied data are deterministic synthetic
word fixtures and declared numerical increments.

## CPU reproduction and file map

```sh
python tools/validate.py --proofs
python tools/verify_run.py results/demo_morton
python tools/seal_run.py results/demo_morton --verify
python tools/verify_package.py
python tools/verify_evidence.py
```

| Path | Contents |
|---|---|
| `cuda/kernel.cu` | Texture/global CUDA entry points, resource ownership and event timing |
| `include/atomos/core.hpp` | Shared operator definitions and invariant bank |
| `include/atomos/host.hpp` | Dictionary layout, fixture, independent bit oracle and commit checks |
| `include/atomos/log_polar.hpp` | Explicit host log-polar coordinate map |
| `src/main.cpp` | CLI, multi-epoch launcher, staged file output and final commit |
| `python/reference.py` | Independent fixture reconstruction and every-row conformance check |
| `python/provenance.py` | Symbolic genesis, full identity digest and run seal |
| `proofs/` | SMT-LIB obligations, solver runner and analytic proof notes |
| `tests/` | CPU and independent Python tests |
| `tools/validate.py` | Reproducible CPU/GPU evidence matrix |
| `AGENTS.md`, `CODEX_REVIEW.md` | Codex review contract and ready-to-use task |
| `results/` | Actual executed evidence, example run and explicit pending statuses |

The package manifest checks byte integrity, not author authentication. Changing a
file invalidates its original manifest entry. Toolkits, drivers, Z3 binaries, font
files and the original private PDF corpus are not bundled.
