import json,math,random,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'python'))
from reference import bit_core,producer,observe,bank,wrap,address,canonical,U32
from provenance import identity,seal_run,verify_seal,FILES
class ReferenceTests(unittest.TestCase):
 def a(self,**extra):return dict(dr=1.,dp=1.,alpha=0.,interval=.125,profile=0,axis_known=1,frame_known=1,increment_known=1,**extra)
 def test_morton_tile(self):self.assertEqual({address(r,w,8,'morton8') for r in range(8) for w in range(8)},set(range(64)))
 def test_morton_order(self):self.assertEqual(address(1,0,8,'morton8'),1);self.assertEqual(address(0,1,8,'morton8'),2)
 def test_absorb_not_clear(self):self.assertEqual(bit_core(255,U32,U32,128,U32,U32),(255,255,1,0))
 def test_zero(self):self.assertEqual(bit_core(0,U32,U32,U32,U32,U32),(0,0,0,0))
 def test_fringe_nonmonotone(self):self.assertEqual(bit_core(3,3,3,2,3,3)[3],0);self.assertEqual(bit_core(3,3,3,2,3,1)[3],1)
 def test_source_ratio(self):self.assertEqual(observe(self.a())['beta'],math.pi/4)
 def test_axis_unavailable(self):a=self.a();a['axis_known']=0;o=observe(a);self.assertEqual(o['status'],5);self.assertIsNone(o['raw']);self.assertIsNotNone(o['beta'])
 def test_completion_explicit(self):a=self.a();a['dr']=0;self.assertEqual(observe(a)['status'],2);a['profile']=1;self.assertEqual(observe(a)['beta'],math.pi/2)
 def test_zero_motion(self):a=self.a();a.update(dr=0,dp=0);self.assertEqual(observe(a)['status'],1)
 def test_raw_residual(self):a=self.a();a['alpha']=4;o=observe(a);self.assertLess(o['raw'],-math.pi);self.assertGreater(o['principal'],0)
 def test_bank_default(self):a=self.a();self.assertEqual([x['state'] for x in bank(a,observe(a))],[0]*6)
 def test_bank_bad_interval(self):a=self.a();a['interval']=0;self.assertEqual([x['state'] for x in bank(a,observe(a))],[0,2,0,0,0,0])
 def test_wrap_seam(self):self.assertAlmostEqual(wrap(math.radians(1-359)),math.radians(2));self.assertEqual(wrap(math.pi),-math.pi)
 def test_producer_variants(self):l={'initial_word':17,'jitter':0};self.assertEqual(producer(5,l,'shift-xor'),8);self.assertEqual(producer(5,l,'shift-or'),10);l['jitter']=U32;self.assertEqual(producer(0,l,'shift-xor'),0)
 def test_bitset_random_contraction(self):
  g=random.Random(36)
  for _ in range(500):
   x,a,n,b,v,f=[g.getrandbits(32) for _ in range(6)]
   result=bit_core(x,a,n,b,v,f)
   self.assertEqual(result[3]&~x,0)
   self.assertEqual(bit_core(result[3],a,n,b,v,f)[3],result[3])
 def test_identity_order_and_width(self):self.assertEqual(identity(['b','a']),identity(['a','b','a']));self.assertEqual(len(identity(['a'])['digest256']),64)
 def test_unicode_normalization(self):self.assertEqual(identity(['cafe\u0301']),identity(['café']))
 def test_canonical_finite(self):
  with self.assertRaises(ValueError):canonical({'x':math.nan})
 def test_seal_detects_changes(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)
   for n in FILES:(p/n).write_bytes(b'fixture\n')
   seal_run(p,['synthetic']);self.assertTrue(verify_seal(p));(p/'trace.csv').write_bytes(b'changed\n');self.assertFalse(verify_seal(p))
 def test_seal_refuses_replacement(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)
   for n in FILES:(p/n).write_bytes(b'fixture\n')
   seal_run(p,['synthetic'])
   with self.assertRaises(ValueError):seal_run(p,['synthetic'])
if __name__=='__main__':unittest.main()
