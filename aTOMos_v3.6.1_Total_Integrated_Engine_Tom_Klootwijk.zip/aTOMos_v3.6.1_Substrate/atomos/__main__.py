from __future__ import annotations
import argparse
import json
from pathlib import Path
from .engine import Engine
from .records import load_json


def main() -> None:
    p = argparse.ArgumentParser(description='aTOMos v3.6.1 local epoch reference')
    p.add_argument('--profile', type=Path, required=True)
    p.add_argument('--batch', type=Path, required=True)
    p.add_argument('--out', type=Path)
    args = p.parse_args()
    try:
        engine = Engine(load_json(args.profile))
        result = engine.process(load_json(args.batch))
        text = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
        if args.out:
            with args.out.open('x', encoding='utf-8') as file:
                file.write(text)
        else:
            print(text, end='')
    except (ValueError, KeyError, TypeError, OSError) as error:
        p.exit(1, f'aTOMos input/result error: {error}\n')


if __name__ == '__main__':
    main()
