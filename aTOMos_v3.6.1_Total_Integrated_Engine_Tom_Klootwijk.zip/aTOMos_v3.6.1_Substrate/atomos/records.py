"""Versioned canonical values and replayable record hashes; standard library only."""
from __future__ import annotations
import hashlib
import json
import math
import unicodedata
from pathlib import Path
from typing import Any


def exact(value: Any) -> Any:
    """Tagged form avoids collisions between floats and user-supplied dictionaries."""
    if value is None:
        return ['null']
    if type(value) is bool:
        return ['bool', value]
    if type(value) is int:
        return ['int', str(value)]
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError('nonfinite numbers are statuses, not serializable values')
        return ['float64', (0.0 if value == 0 else value).hex()]
    if type(value) is str:
        return ['str', value]
    if type(value) in (list, tuple):
        return ['list', [exact(v) for v in value]]
    if type(value) is dict:
        if any(type(k) is not str for k in value):
            raise ValueError('record keys must be strings')
        return ['map', [[k, exact(value[k])] for k in sorted(value, key=lambda k: k.encode('utf-8'))]]
    raise TypeError(f'unsupported record type: {type(value).__name__}')


def canonical(value: Any) -> bytes:
    return json.dumps(exact(value), ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value: Any, domain: bytes = b'aTOMos:record:3.6.1\0') -> str:
    data = canonical(value)
    return hashlib.sha256(domain + len(data).to_bytes(8, 'big') + data).hexdigest()


def genesis(labels: list[str]) -> dict:
    if not labels or any(type(s) is not str or not s for s in labels):
        raise ValueError('nonempty symbolic genesis labels required')
    members = sorted({unicodedata.normalize('NFC', s) for s in labels}, key=lambda s: s.encode('utf-8'))
    record = {'schema': 'aTOMos-genesis-3.6.1', 'members': members}
    return {'record': record, 'sha256': digest(record, b'aTOMos:genesis:3.6.1\0')}


def event_head(previous: str, record: dict) -> str:
    if len(previous) != 64 or any(c not in '0123456789abcdef' for c in previous):
        raise ValueError('canonical lowercase 256-bit previous head required')
    data = canonical(record)
    return hashlib.sha256(b'aTOMos:epoch:3.6.1\0' + bytes.fromhex(previous) + len(data).to_bytes(8, 'big') + data).hexdigest()


def verify_events(events: list[dict], anchor: str) -> bool:
    current = anchor
    try:
        for item in events:
            if set(item) != {'record', 'previous', 'head'} or item['previous'] != current:
                return False
            expected = event_head(current, item['record'])
            if expected != item['head']:
                return False
            current = expected
    except (ValueError, TypeError, KeyError):
        return False
    return True


def load_json(path: Path) -> Any:
    def duplicates(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f'duplicate JSON key: {key}')
            result[key] = value
        return result
    def bad_constant(value):
        raise ValueError(f'nonstandard numeric constant: {value}')
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=duplicates,
                      parse_constant=bad_constant)
