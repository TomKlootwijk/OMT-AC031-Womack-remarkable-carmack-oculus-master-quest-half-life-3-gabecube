"""Declared finite chart, storage permutation and generic numerical utilities."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence
import math
from .core import integer, U32
from .orientation import finite, TAU


@dataclass(frozen=True)
class Shape:
    rows: int
    angles: int

    def __post_init__(self) -> None:
        integer(self.rows, 'rows', 1, 65536)
        integer(self.angles, 'angles', 1, 65536)

    @property
    def words(self) -> int:
        return (self.angles + 31) // 32

    @property
    def padded_rows(self) -> int:
        return (self.rows + 7) // 8 * 8

    @property
    def padded_words(self) -> int:
        return (self.words + 7) // 8 * 8

    @property
    def logical_size(self) -> int:
        return self.rows * self.words

    def valid(self, word_index: int) -> int:
        integer(word_index, 'word_index', 0, self.words - 1)
        tail = self.angles % 32
        return (1 << tail) - 1 if tail and word_index == self.words - 1 else U32


def morton3(radial: int, angular_word: int) -> int:
    integer(radial, 'radial', 0, 7)
    integer(angular_word, 'angular_word', 0, 7)
    return sum(((radial >> i) & 1) << (2 * i) |
               ((angular_word >> i) & 1) << (2 * i + 1) for i in range(3))


def address(shape: Shape, radial: int, angular_word: int, layout: str) -> int:
    integer(radial, 'radial', 0, shape.padded_rows - 1)
    integer(angular_word, 'angular_word', 0, shape.padded_words - 1)
    if layout == 'linear':
        return radial * shape.padded_words + angular_word
    if layout != 'morton8':
        raise ValueError('layout must be linear or morton8')
    tile = (radial // 8) * (shape.padded_words // 8) + angular_word // 8
    return 64 * tile + morton3(radial % 8, angular_word % 8)


def decode(shape: Shape, index: int, layout: str) -> tuple[int, int]:
    integer(index, 'index', 0, shape.padded_rows * shape.padded_words - 1)
    if layout == 'linear':
        return divmod(index, shape.padded_words)
    if layout != 'morton8':
        raise ValueError('layout must be linear or morton8')
    tile, inside = divmod(index, 64)
    row_tile, word_tile = divmod(tile, shape.padded_words // 8)
    r = sum(((inside >> (2 * i)) & 1) << i for i in range(3))
    w = sum(((inside >> (2 * i + 1)) & 1) << i for i in range(3))
    return row_tile * 8 + r, word_tile * 8 + w


def chart(radius: float, phase: float, reference_radius: float = 1.0) -> tuple[float, float]:
    if not all(finite(x) for x in (radius, phase, reference_radius)) or radius <= 0 or reference_radius <= 0:
        raise ValueError('chart requires finite positive radii and finite phase')
    return math.log(radius) - math.log(reference_radius), phase


def calibrate(di: float, dj: float, h_rho: float, h_phi: float) -> tuple[float, float]:
    if not all(finite(x) for x in (di, dj, h_rho, h_phi)) or h_rho <= 0 or h_phi <= 0:
        raise ValueError('finite index changes and positive chart spacings required')
    values = h_rho * di, h_phi * dj
    if not all(finite(v) for v in values):
        raise ValueError('calibration result outside numeric range')
    return values


def klein(u: float, v: float) -> tuple[float, float, int]:
    if not finite(u) or not finite(v):
        raise ValueError('finite quotient coordinates required')
    k = math.floor(v)
    sign = -1 if k % 2 else 1
    return (sign * u) % 1.0, v - k, sign


def rk4(field: Callable[[float, tuple[float, ...]], Sequence[float]], t: float,
        state: Sequence[float], dt: float) -> tuple[float, ...]:
    y = tuple(state)
    if not y or not all(finite(v) for v in y) or not finite(t) or not finite(dt) or dt <= 0:
        raise ValueError('finite state/time and positive step required')
    def f(time: float, z: tuple[float, ...]) -> tuple[float, ...]:
        if not finite(time) or not all(finite(v) for v in z):
            raise ValueError('RK4 intermediate outside numeric range')
        values = tuple(field(time, z))
        if len(values) != len(y) or not all(finite(v) for v in values):
            raise ValueError('field output dimension or finite-domain mismatch')
        return values
    def add(k, scale):
        return tuple(v + scale * d for v, d in zip(y, k))
    k1 = f(t, y)
    k2 = f(t + dt / 2, add(k1, dt / 2))
    k3 = f(t + dt / 2, add(k2, dt / 2))
    k4 = f(t + dt, add(k3, dt))
    out = tuple(v + dt / 6 * (a + 2*b + 2*c + d) for v, a, b, c, d in zip(y, k1, k2, k3, k4))
    if not all(finite(v) for v in out):
        raise ValueError('RK4 output outside numeric range')
    return out
