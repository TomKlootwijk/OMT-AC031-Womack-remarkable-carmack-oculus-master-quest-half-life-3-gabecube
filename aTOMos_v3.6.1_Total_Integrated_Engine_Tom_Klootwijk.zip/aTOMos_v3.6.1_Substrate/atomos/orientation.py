"""Literal OTAN2 and the separately named completion. All outputs are records."""
from __future__ import annotations
import math
from typing import Any

TAU = 2 * math.pi
PROFILES = ('source_ratio', 'directed_completion_1')


def finite(x: object) -> bool:
    if type(x) not in (float, int):
        return False
    try:
        return math.isfinite(x)
    except (OverflowError, TypeError):
        return False


def wrap(x: float, period: float = TAU) -> float:
    if not finite(x) or not finite(period) or period <= 0:
        raise ValueError('finite angle and positive finite period required')
    x = math.fmod(x, period)
    if x >= period / 2:
        x -= period
    if x < -period / 2:
        x += period
    return 0.0 if x == 0 else x


def otan2(delta_phi: float, delta_rho: float, profile: str = 'source_ratio') -> dict:
    def unavailable(status: str) -> dict:
        return {'status': status, 'value': None}
    if profile not in PROFILES:
        return unavailable('profile_unspecified')
    if not finite(delta_phi) or not finite(delta_rho):
        return unavailable('nonfinite_input')
    if delta_phi == delta_rho == 0:
        return unavailable('zero_increment')
    if profile == 'source_ratio':
        if delta_rho == 0:
            return unavailable('ratio_undefined')
        ratio = delta_phi / delta_rho
        if not finite(ratio) or (delta_phi != 0 and ratio == 0):
            return unavailable('numerical_range')
        value = math.atan(ratio)
    else:
        value = wrap(math.atan2(delta_phi, delta_rho))
    return {'status': 'defined', 'value': 0.0 if value == 0 else value}


def observation(delta_rho: float, delta_phi: float, axis_angle: float | None,
                profile: str = 'source_ratio', frame: str = 'log_tangent',
                increment_policy: str = 'explicit_increment') -> dict[str, Any]:
    raw = otan2(delta_phi, delta_rho, profile)
    out = {'profile': profile, 'orientation_status': raw['status'], 'status': raw['status'],
           'beta': raw['value'], 'residual_raw': None, 'residual_principal': None,
           'residual_line': None}
    if raw['status'] != 'defined':
        return out
    if frame != 'log_tangent':
        out['status'] = 'frame_unspecified'
    elif increment_policy != 'explicit_increment':
        out['status'] = 'increment_policy_unspecified'
    elif axis_angle is None:
        out['status'] = 'axis_unspecified'
    elif not finite(axis_angle):
        out['status'] = 'nonfinite_input'
    else:
        e = raw['value'] - axis_angle
        if not finite(e):
            out['status'] = 'numerical_range'
        else:
            out.update(status='defined', residual_raw=e,
                       residual_principal=wrap(e), residual_line=wrap(e, math.pi))
    return out


def endpoint_increment(phi0: float, phi1: float, policy: str,
                       turns: int | None = None) -> dict:
    if not finite(phi0) or not finite(phi1):
        return {'status': 'nonfinite_input', 'value': None}
    d = phi1 - phi0
    if not finite(d):
        return {'status': 'numerical_range', 'value': None}
    if policy == 'principal_difference':
        return {'status': 'defined', 'value': wrap(d)}
    if policy == 'known_turns' and type(turns) is int:
        try:
            value = d + TAU * turns
        except OverflowError:
            value = math.inf
        return {'status': 'defined' if finite(value) else 'numerical_range',
                'value': value if finite(value) else None}
    return {'status': 'turn_information_unspecified', 'value': None}


def invariant_bank(delta_rho: float, delta_phi: float, axis_angle: float | None,
                   profile: str = 'source_ratio', interval: float = 1.0,
                   scale: float = 3.0, rotation: float = 0.4,
                   tolerance: float = 1e-10) -> dict:
    """Four identities and two profile laws, evaluated on one declared snapshot."""
    if not finite(tolerance) or tolerance < 0:
        raise ValueError('finite nonnegative comparison tolerance required')
    base = observation(delta_rho, delta_phi, axis_angle, profile)
    checks: dict[str, dict] = {}
    def undefined(key: str, reason: str) -> None:
        checks[key] = {'status': 'UNDEFINED', 'error_rad': None, 'reason': reason}
    def compare(key: str, left: float, right: float, period: float | None = None) -> None:
        d = left - right
        if not finite(d):
            undefined(key, 'numerical_range')
            return
        e = abs(wrap(d, period)) if period else abs(d)
        checks[key] = {'status': 'PASS' if e <= tolerance else 'FAIL', 'error_rad': e,
                       'comparison_period_rad': period}
    if base['status'] != 'defined':
        for key in 'RWPSFV':
            undefined(key, base['status'])
        return checks
    e0 = base['residual_raw']
    def transformed(key: str, dr: float, dp: float, alpha: float, period=None) -> None:
        out = observation(dr, dp, alpha, profile)
        if out['status'] != 'defined':
            undefined(key, out['status'])
        else:
            compare(key, out['residual_raw'], e0, period)
    transformed('R', ((0.75 + delta_rho) + math.log(10)) - (0.75 + math.log(10)),
                delta_phi, axis_angle)
    if not finite(interval) or interval <= 0:
        undefined('W', 'invalid_common_interval')
    else:
        dr, dp = delta_rho / interval, delta_phi / interval
        if (delta_rho != 0 and dr == 0) or (delta_phi != 0 and dp == 0):
            undefined('W', 'numerical_range')
        else:
            transformed('W', dr, dp, axis_angle)
    transformed('P', delta_rho, ((0.25 + delta_phi) + 0.75) - 1.0, axis_angle)
    if not finite(scale) or scale <= 0:
        undefined('S', 'invalid_positive_scale')
    else:
        dr, dp = delta_rho * scale, delta_phi * scale
        if (delta_rho != 0 and dr == 0) or (delta_phi != 0 and dp == 0):
            undefined('S', 'numerical_range')
        else:
            transformed('S', dr, dp, axis_angle)
    if not finite(rotation):
        undefined('F', 'rotation_unspecified')
    else:
        c, s = math.cos(rotation), math.sin(rotation)
        dr, dp = c * delta_rho - s * delta_phi, s * delta_rho + c * delta_phi
        if profile == 'source_ratio' and abs(dr) <= 64 * math.ulp(1.0) * math.hypot(delta_rho, delta_phi):
            undefined('F', 'rotated_ratio_ill_conditioned')
        else:
            transformed('F', dr, dp, axis_angle + rotation,
                        math.pi if profile == 'source_ratio' else TAU)
    reverse = otan2(-delta_phi, -delta_rho, profile)
    if reverse['status'] != 'defined':
        undefined('V', reverse['status'])
    elif profile == 'source_ratio':
        compare('V', reverse['value'], base['beta'])
    else:
        compare('V', reverse['value'] - base['beta'], math.pi, TAU)
    return checks
