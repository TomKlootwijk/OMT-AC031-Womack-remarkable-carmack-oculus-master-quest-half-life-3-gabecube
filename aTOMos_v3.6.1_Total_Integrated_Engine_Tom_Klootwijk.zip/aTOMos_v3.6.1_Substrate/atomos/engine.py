"""Atomic local epochs over preprocessed word records. No runtime policy service."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from typing import Any
from .core import asa_word, blend, jk, bit, word, integer
from .geometry import Shape, calibrate
from .orientation import observation, invariant_bank, finite, PROFILES
from .records import digest, event_head


def required_string(value: Any, name: str) -> str:
    if type(value) is not str or not value:
        raise ValueError(f'{name}: nonempty string required')
    return value


@dataclass(frozen=True)
class State:
    epoch: int
    q: int
    words: tuple[int, ...]
    last_end_ns: int | None
    head: str


class Engine:
    """The supplied reference implements local_preprocessed_words/1 only.

    Unsupported physical acquisition belongs to a separate producer, not to a
    hidden fallback. Configuration and record data never execute as program text.
    """
    def __init__(self, profile: dict):
        self._profile = deepcopy(profile)
        p = self._profile
        if p.get('schema') != 'aTOMos-profile-1' or p.get('engine_version') != '3.6.1':
            raise ValueError('unsupported profile schema or engine version')
        if p.get('execution', {}).get('model') != 'local_preprocessed_words/1':
            raise ValueError('this reference does not implement the selected producer model')
        required_string(p.get('profile_id'), 'profile_id')
        d = p['dictionary']
        required_string(d.get('id'), 'dictionary.id')
        self.shape = Shape(d['rows'], d['angles'])
        if d.get('ordering') != 'logical_row_major_words' or d.get('frame') != 'log_tangent':
            raise ValueError('dictionary ordering/frame mismatch')
        n = self.shape.logical_size
        for key in ('asa', 'na', 'boundary', 'fringe'):
            plane = p['masks'][key]
            if type(plane) is not list or len(plane) != n:
                raise ValueError(f'{key}: exactly {n} logical words required')
            for i, value in enumerate(plane):
                word(value, key)
                if value & ~self.shape.valid(i % self.shape.words):
                    raise ValueError(f'{key}: nonzero bits beyond declared angular dimension')
        if p['execution'].get('fringe_mode') not in ('record', 'explicit_mask'):
            raise ValueError('unknown fringe mode')
        if p['execution'].get('otan2_profile') not in PROFILES:
            raise ValueError('unknown OTAN2 profile')
        if p['execution'].get('jk_policy') != 'explicit_events':
            raise ValueError('JK producer must supply explicit events in this reference')
        scale = p['transfer']
        calibrate(0, 0, scale['h_rho'], scale['h_phi'])
        if scale.get('kind') != 'index_scale/1':
            raise ValueError('unknown transfer representation')
        if scale.get('phase_unit') != 'rad' or scale.get('rho_unit') != 'ln_ratio':
            raise ValueError('transfer units mismatch')
        self.profile_digest = digest(p, b'aTOMos:profile:3.6.1\0')
        q = bit(p['initial_q'], 'initial_q')
        self._state = State(0, q, tuple(0 for _ in range(n)), None, self.profile_digest)
        self._events: list[dict] = []

    @property
    def state(self) -> State:
        return self._state

    @property
    def profile(self) -> dict:
        return deepcopy(self._profile)

    @property
    def events(self) -> list[dict]:
        return deepcopy(self._events)

    def _batch(self, batch: dict) -> tuple[dict, list[dict]]:
        b = deepcopy(batch)
        if b.get('schema') != 'aTOMos-batch-1':
            raise ValueError('unsupported input batch schema')
        if b.get('profile_sha256') != self.profile_digest:
            raise ValueError('batch does not reference this profile snapshot')
        if b.get('epoch') != self._state.epoch or type(b.get('epoch')) is not int:
            raise ValueError('batch epoch does not match state epoch')
        for name in ('batch_id', 'clock_id', 'frame_id'):
            required_string(b.get(name), name)
        if b['frame_id'] != 'log_tangent':
            raise ValueError('unconverted input frame')
        if b.get('dictionary_id') != self._profile['dictionary']['id']:
            raise ValueError('dictionary identifier mismatch')
        start = integer(b.get('start_ns'), 'start_ns', 0, (1 << 63) - 1)
        end = integer(b.get('end_ns'), 'end_ns', 1, (1 << 63) - 1)
        if end <= start:
            raise ValueError('batch interval must be nonempty and half-open')
        if self._state.last_end_ns is not None and start < self._state.last_end_ns:
            raise ValueError('new batch overlaps a committed batch interval')
        records = b.get('records')
        if type(records) is not list or len(records) != self.shape.logical_size:
            raise ValueError('batch must contain exactly one record per logical word')
        seen = set()
        for r in records:
            if type(r) is not dict:
                raise ValueError('record object required')
            for key in ('batch_id', 'clock_id', 'frame_id'):
                if r.get(key) != b[key]:
                    raise ValueError(f'mixed {key} inside coherent batch')
            if r.get('profile_sha256') != self.profile_digest:
                raise ValueError('mixed profile snapshot inside batch')
            t = integer(r.get('timestamp_ns'), 'timestamp_ns', start, end - 1)
            index = integer(r.get('word'), 'logical word', 0, self.shape.logical_size - 1)
            if index in seen:
                raise ValueError('duplicate logical word record')
            seen.add(index)
            word(r.get('occupancy'), 'occupancy')
            if r['occupancy'] & ~self.shape.valid(index % self.shape.words):
                raise ValueError('input occupancy has nonzero tail bits')
            required_string(r.get('source_label'), 'source_label')
            # Explicit statuses are resolved before mask evaluation; they do not
            # become masks unless a separate profile defines that map.
            for key in ('alignment', 'sweep_limit', 'active_fringe'):
                value = r.get(key, {'status': 'unspecified'})
                if type(value) is not dict or value.get('status') not in ('defined', 'unspecified'):
                    raise ValueError(f'{key}: invalid predicate record')
                if value['status'] == 'defined':
                    bit(value.get('value'), key)
            if 'blend_bits' in r:
                if type(r['blend_bits']) is not list or len(r['blend_bits']) != 3:
                    raise ValueError('blend_bits requires three values')
                for v in r['blend_bits']:
                    bit(v, 'blend_bit')
            if 'orientation' in r:
                o = r['orientation']
                if type(o) is not dict or o.get('kind') not in ('explicit_increment', 'index_delta'):
                    raise ValueError('orientation needs an explicit representation kind')
                values = ('delta_rho', 'delta_phi') if o['kind'] == 'explicit_increment' else ('delta_i', 'delta_j')
                for key in values:
                    if not finite(o.get(key)):
                        raise ValueError(f'orientation.{key}: finite numeric value required')
                if o.get('axis_angle') is not None and not finite(o['axis_angle']):
                    raise ValueError('axis_angle must be finite or null')
        events = b.get('jk_events', [])
        if type(events) is not list:
            raise ValueError('jk_events must be an ordered list')
        previous_t = start
        for event in events:
            integer(event.get('timestamp_ns'), 'JK event time', start, end - 1)
            if event['timestamp_ns'] < previous_t:
                raise ValueError('JK events are not time ordered')
            previous_t = event['timestamp_ns']
            bit(event.get('j'), 'j'); bit(event.get('k'), 'k')
        return b, sorted(records, key=lambda r: r['word'])

    def process(self, batch: dict) -> dict:
        """Produce one immutable-result epoch. Validation failure changes no state."""
        b, records = self._batch(batch)
        p = self._profile
        q = self._state.q
        q_trace = []
        for event in b.get('jk_events', []):
            after = jk(q, event['j'], event['k'])
            q_trace.append({**event, 'before': q, 'after': after})
            q = after
        result_records = []
        for r in records:
            i = r['word']
            valid = self.shape.valid(i % self.shape.words)
            fringe = p['masks']['fringe'][i] if p['execution']['fringe_mode'] == 'explicit_mask' else valid
            core = asa_word(r['occupancy'], p['masks']['asa'][i], p['masks']['na'][i],
                            p['masks']['boundary'][i], valid, fringe)
            out = {'word': i, 'source_label': r['source_label'], 'timestamp_ns': r['timestamp_ns'],
                   'core': core.as_dict(), 'predicates': {k: r.get(k, {'status': 'unspecified'})
                           for k in ('alignment', 'sweep_limit', 'active_fringe')},
                   'blend': {'status': 'unspecified'}, 'otan2': {'status': 'input_unspecified'},
                   'invariants': {}}
            if 'blend_bits' in r:
                out['blend'] = {'status': 'defined', 'value': blend(*r['blend_bits'])}
            if 'orientation' in r:
                o = r['orientation']
                if o['kind'] == 'index_delta':
                    dr, dp = calibrate(o['delta_i'], o['delta_j'], p['transfer']['h_rho'], p['transfer']['h_phi'])
                else:
                    dr, dp = o['delta_rho'], o['delta_phi']
                alpha = o.get('axis_angle')
                op = p['execution']['otan2_profile']
                out['otan2'] = observation(dr, dp, alpha, op)
                out['otan2']['input_units'] = {'delta_rho': 'ln_ratio', 'delta_phi': 'rad', 'axis_angle': 'rad'}
                out['otan2']['calibrated_increment'] = [dr, dp]
                interval = (b['end_ns'] - b['start_ns']) / 1e9
                out['invariants'] = invariant_bank(dr, dp, alpha, op, interval=interval)
            result_records.append(out)
        report = {'schema': 'aTOMos-epoch-3.6.1', 'engine': 'aTOMos', 'version': '3.6.1',
                  'profile_id': p['profile_id'], 'profile_sha256': self.profile_digest,
                  'epoch': self._state.epoch, 'batch_id': b['batch_id'], 'clock_id': b['clock_id'],
                  'start_ns': b['start_ns'], 'end_ns': b['end_ns'], 'dictionary_id': b['dictionary_id'],
                  'input_sha256': digest(b), 'records': result_records,
                  'jk': {'before': self._state.q, 'after': q, 'events': q_trace}}
        head = event_head(self._state.head, report)
        envelope = {'record': report, 'previous': self._state.head, 'head': head}
        new_state = State(self._state.epoch + 1, q, tuple(x['core']['output'] for x in result_records), b['end_ns'], head)
        # The state and in-memory ledger publish together only after every step succeeds.
        self._events.append(deepcopy(envelope))
        self._state = new_state
        return deepcopy(envelope)
