"""Sparse finite-prefix interpreter for the separate abstract U profile."""
from __future__ import annotations
from dataclasses import dataclass, field
from .core import bit


@dataclass
class TapeMachine:
    rules: dict[tuple[int, int], tuple[int, int, int]]
    q: int = 0
    halt_state: int = 1
    head: int = 0
    cells: dict[int, int] = field(default_factory=dict)
    steps: int = 0

    def step(self) -> str:
        if self.q == self.halt_state:
            return 'halted'
        symbol = self.cells.get(self.head, 0)
        bit(symbol)
        rule = self.rules.get((self.q, symbol))
        if rule is None:
            return 'missing_rule'
        next_state, write, move = rule
        bit(write)
        if type(next_state) is not int or next_state < 0 or type(move) is not int or move not in (-1, 0, 1):
            raise ValueError('invalid instruction')
        if write:
            self.cells[self.head] = write
        else:
            self.cells.pop(self.head, None)
        self.q, self.head, self.steps = next_state, self.head + move, self.steps + 1
        return 'halted' if self.q == self.halt_state else 'running'

    def run(self, budget: int) -> str:
        if type(budget) is not int or budget < 0:
            raise ValueError('nonnegative integer execution budget required')
        if self.q == self.halt_state:
            return 'halted'
        for _ in range(budget):
            status = self.step()
            if status != 'running':
                return status
        return 'budget_exhausted'
