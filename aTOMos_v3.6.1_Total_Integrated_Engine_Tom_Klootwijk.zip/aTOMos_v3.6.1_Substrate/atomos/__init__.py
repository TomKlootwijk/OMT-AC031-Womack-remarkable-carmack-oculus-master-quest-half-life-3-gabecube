"""aTOMos v3.6.1: local, inspectable knowledge-kernel reference."""
__version__ = '3.6.1'
from .core import asa_word, jk, blend, shift_merge
from .orientation import otan2, observation, invariant_bank
from .engine import Engine
__all__ = ['Engine', 'asa_word', 'jk', 'blend', 'shift_merge', 'otan2', 'observation', 'invariant_bank']
