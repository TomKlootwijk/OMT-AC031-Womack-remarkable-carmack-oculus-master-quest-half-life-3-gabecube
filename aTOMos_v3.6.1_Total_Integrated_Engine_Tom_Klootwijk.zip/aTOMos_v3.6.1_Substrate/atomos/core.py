"""Exact finite-word algebra. Source/fixture choices are documented in the PDF."""
from __future__ import annotations
from dataclasses import dataclass

U32 = (1 << 32) - 1


def integer(value: object, name: str, low: int, high: int) -> int:
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f'{name}: expected integer in {low}..{high}')
    return value


def word(value: object, name: str = 'word') -> int:
    return integer(value, name, 0, U32)


def bit(value: object, name: str = 'bit') -> int:
    return integer(value, name, 0, 1)


@dataclass(frozen=True)
class WordResult:
    asa: int
    na: int
    hits: int
    output: int

    def as_dict(self) -> dict[str, int]:
        return {'asa': self.asa, 'na': self.na, 'hits': self.hits, 'output': self.output}


def asa_word(x: int, aperture: int, na: int, boundary: int,
             valid: int = U32, fringe: int | None = None) -> WordResult:
    """ASA -> NA -> count -> whole-word disposition, not per-bit clearing."""
    for name, value in [('x', x), ('aperture', aperture), ('na', na),
                        ('boundary', boundary), ('valid', valid)]:
        word(value, name)
    if fringe is None:
        fringe = valid
    word(fringe, 'fringe')
    a = x & aperture & valid & fringe
    n = a & na
    h = (n & boundary).bit_count()
    return WordResult(a, n, h, 0 if h else n)


def blend(n: int, a: int, b: int) -> int:
    return bit(n, 'north_bit') ^ bit(a, 'axis_bit') ^ bit(b, 'kinematic_bit')


def jk(q: int, j: int, k: int) -> int:
    q, j, k = bit(q, 'q'), bit(j, 'j'), bit(k, 'k')
    return (j & (q ^ 1)) | ((k ^ 1) & q)


def event_pair(event: str) -> tuple[int, int]:
    """Explicit symbolic input events; no observation-to-actuator policy."""
    table = {'hold': (0, 0), 'set': (1, 0), 'reset': (0, 1), 'toggle': (1, 1)}
    if event not in table:
        raise ValueError('event must be hold, set, reset or toggle')
    return table[event]


def shift_merge(psi: int, jitter: int, width: int = 32, merge: str = 'xor',
                zero_absorbing: bool = True) -> int:
    width = integer(width, 'width', 1, 64)
    limit = (1 << width) - 1
    integer(psi, 'psi', 0, limit)
    integer(jitter, 'jitter', 0, limit)
    if merge not in ('xor', 'or'):
        raise ValueError('merge must be xor or or')
    if type(zero_absorbing) is not bool:
        raise ValueError('zero_absorbing must be Boolean')
    if zero_absorbing and psi == 0:
        return 0
    left, right = (psi << 1) & limit, psi >> 1
    merged = left ^ right if merge == 'xor' else left | right
    return merged ^ jitter


def child_id(parent: int, side: int, width: int = 64) -> int:
    integer(width, 'width', 2, 4096)
    integer(parent, 'parent', 1, (1 << width) - 1)
    bit(side, 'side')
    if parent > ((1 << width) - 1) >> 1:
        raise OverflowError('lineage would exceed declared address width')
    return (parent << 1) | side


def facet_union(words: list[int]) -> int:
    out = 0
    for value in words:
        out |= word(value)
    return out
