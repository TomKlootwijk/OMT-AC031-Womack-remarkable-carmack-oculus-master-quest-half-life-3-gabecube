# 3.6.1 / M2 / S1 — 14 September 2026

Rebuild the entire v3.6 master as a standalone integrated specification. Incorporate
the supplied Markdown's configuration, coherent-batch, physics-slot and feedback-slot
requirements as a named foundational profile. Preserve the source's unresolved
hardware parameters and separately bind a complete local mathematical fixture.

Add local Python word-epoch implementation, pure math utilities, typed profiles,
JSON schemas, canonical records, replay evidence and blue-team regressions. Keep
literal OTAN2 and its completion distinct. Keep ASA/NA/whole-word semantics and
explicit JK events. Do not add remote activation, telemetry or license enforcement.
