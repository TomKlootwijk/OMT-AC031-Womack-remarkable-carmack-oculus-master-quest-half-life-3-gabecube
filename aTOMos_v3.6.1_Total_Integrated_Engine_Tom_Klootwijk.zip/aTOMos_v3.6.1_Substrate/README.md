# aTOMos v3.6.1 — Total Integrated Engine / Foundational Substrate

**Author:** Tom Klootwijk · **NL200678942** · **10-07-1990**  
**Family:** atomOS v3.6 · **Release:** 3.6.1 · **Master:** M2 · **Substrate:** S1  
**Date:** 14 September 2026

This package contains the consolidated master PDF, its editable LaTeX, a local
Python reference, explicit profile schemas, a complete mathematical fixture,
blue-team regression tests and the new attached source document.

## Read the two profiles correctly

`profiles/foundation.json` defines the inherited engine contracts and every new
extension slot named by **Pasted markdown.md**. It includes source locations,
required types, units and binding status. The attachment does not provide actual
propagation equations, array coefficients, calibration values or an angle-to-J/K
policy. Their source status is preserved as `declared_unbound`.

`profiles/local_reference.json` is a **fully supplied mathematical test profile**.
Its constant RK4 field, test matrix, index scales, masks and JK inputs are explicit
worked-example choices, not fabricated hardware calibration. It runs without any
of the unbound physical-profile entries.

The full PDF integrates those profile rules into the whole engine: identity and
state, grammar, chart/topology, RK4, JK, ASA/NA, blend, OTAN2, invariants, coherent
batches, commit semantics, provenance, memory layout and the optional tape model.
It is not merely an appended control-panel specification.

## Run the local epoch

Python 3.10 or later; no third-party packages are required by the runtime or main tests.
From the extracted directory:

```sh
python -m atomos --profile profiles/local_reference.json --batch examples/coherent_batch.json
python tools/run_tests.py
```

To write a result file, add `--out my_epoch.json`. The output path must be new; an
existing file produces an ordinary I/O error rather than replacing earlier evidence.

The independent JavaScript comparison also needs Node:

```sh
python tools/crosscheck.py
```

The example produces word outputs `[14, 0, 0, 85]`, JK state `1`, and the source
OTAN2 orientation pi/4 for each supplied increment. Full results, intermediate
ASA/NA words and the deterministic epoch hash are in `examples/expected_epoch.json`.

## What is implemented

`atomos/core.py` supplies exact ASA -> NA -> population count -> whole-word
absorption, blend parity, JK state, two literal word-merge variants and lineage IDs.
`orientation.py` supplies the literal ratio, the separately named directed completion,
explicit angle/status views and the six invariant/profile checks. `geometry.py`
supplies the declared chart/index conversion, Morton address map, quotient helper
and generic RK4. `tape.py` supplies a small sparse interpreter for the separate U
profile. `engine.py` commits the local word epoch over a coherent preprocessed batch.

The producer implemented by the CLI is `local_preprocessed_words/1`. It does not
contain a raw antenna-acquisition stack, beamforming estimator, physical actuation
adapter, privileged driver or compiled GPU binary. Those are not hidden features
which a token or runtime option activates.

There is no network client, telemetry, remote activation, license check, use-case
classifier or remote shutdown path. Input-domain checks are visible Python code:
word widths, finite values, snapshot identity, timestamp intervals and required
record types. Invalid data produces an ordinary error; the next valid epoch is not
locked out. These checks preserve the stated algebra and the attachment's coherence
requirements.

## Coherent batches

A batch binds one epoch, profile digest, dictionary, frame and clock-domain label.
Each record repeats its batch/clock/frame/profile identity and has a timestamp in
the half-open batch interval. Exactly one record is supplied per logical word.
Input order is retained in the input digest; output words are sorted canonically.
The same clock string is a data label, not proof of physical phase synchronization.

The reference profile uses explicit JK event pairs, not an inferred feedback policy.
Alignment, sweep-limit and active-fringe flags remain separately typed values.
OTAN2 singularities are diagnostic statuses and do not silently reset core or JK
results. Malformed mandatory input rejects the epoch without partial state changes.

## Source distinctions

The new attachment is preserved exactly at `source/Pasted markdown.md`. Its opaque
reference `pdf_v9BtD7.pdf` is not a separately available file in this package. The
current master uses its supplied claims as source text and establishes its own
stable section references. It does not certify those quoted external section numbers.

The source describes OTAN2 as a direction-of-arrival stage. The defined expression
is an orientation of a log-chart **increment pair** relative to a supplied axis;
it does not itself derive an absolute incoming-wave bearing from raw samples.
The PDF gives the mathematical distinction and keeps it separate from the source claim.

`source/manifest.json` fingerprints available original files. The prior M1 contract
was supplied in the conversation history, not as a mounted master-PDF file in this
run. This edition rebuilds one consolidated specification from those established
definitions and the available sources; it does not claim a byte-level patch of a
missing master binary.

## Blue-team evidence

The suite checks bit semantics, malformed types, duplicate JSON keys, mixed clock
and batch IDs, out-of-interval timestamps, stale profile snapshots, repeated epochs,
padding, replay tampering, undefined angles, independence of diagnostics and JK,
and recovery after a rejected batch. It includes independent per-bit and angular
oracles. Actual counts and command outcomes are in `results/validation_status.json`
and `results/cross_runtime.json`; no previous conversation's test count is reused.

## Editing and future variants

Change a copy of a profile and record its parent content digest. Declare every
replacement field and whether its value comes from a source, an actual supplied
measurement, a mathematical derivation or a test fixture. Profile hashes identify
bytes/values; they do not prevent editing or grant an identity special privileges.
No mutable base profile is silently overwritten by a variant.

Use `AGENTS.md` and `docs/CONTRACT.md` as the review entry points. After changing
semantics, add regression tests and update the versioned profile. Re-run the example
generator only when intentionally updating the documented fixtures.

## Build the PDF and check the package

```sh
python tools/make_examples.py
sh tools/build_pdf.sh
python tools/verify_package.py
```

The PDF build needs LaTeX and its preamble packages. The integrity command compares
delivered bytes with an unsigned SHA-256 manifest. Editing files intentionally makes
the original manifest differ; issue a new manifest for a new package revision.
Font files, original private corpus PDFs and vendor binaries are not included.
