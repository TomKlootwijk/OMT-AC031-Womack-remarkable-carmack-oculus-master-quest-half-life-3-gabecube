#!/usr/bin/env python3
"""Verify a saved local epoch against its profile, input and retained chain head."""
from pathlib import Path
import argparse
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from atomos.engine import Engine
from atomos.records import load_json,verify_events
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--profile',type=Path,required=True)
p.add_argument('--batch',type=Path,required=True)
p.add_argument('--result',type=Path,required=True)
a=p.parse_args()
try:
    engine=Engine(load_json(a.profile))
    saved=load_json(a.result)
    if not verify_events([saved],engine.profile_digest):
        raise ValueError('saved event does not match its retained predecessor/hash')
    current=engine.process(load_json(a.batch))
    if current!=saved:
        raise ValueError('recomputed local epoch differs; inspect inputs and numeric environment')
except (OSError,ValueError,KeyError,TypeError) as e:
    print(f'FAIL: {e}');raise SystemExit(1)
print(json.dumps({'status':'passed','profile_sha256':engine.profile_digest,
                  'head':saved['head'],'scope':'exact local re-evaluation and chain check'},indent=2))
