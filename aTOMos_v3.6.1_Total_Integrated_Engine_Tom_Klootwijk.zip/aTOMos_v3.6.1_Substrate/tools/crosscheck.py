#!/usr/bin/env python3
"""Independent JS/Python comparison with reproducible fixture counts."""
from pathlib import Path
import json,random,subprocess,sys,math
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from atomos.core import asa_word
from atomos.orientation import observation
rng=random.Random(361)
words=[[rng.getrandbits(32) for _ in range(6)] for _ in range(2048)]
pairs=[(a,b) for a in (-1,0,1) for b in (-1,0,1)]
pairs += [(rng.uniform(-8,8),rng.uniform(-8,8)) for _ in range(1000)]
angles=[[a,b,rng.uniform(-5,5),p] for a,b in pairs for p in ('source_ratio','directed_completion_1')]
try:
    run=subprocess.run(['node',str(ROOT/'tests/oracle.js')],input=json.dumps({'words':words,'angles':angles}),text=True,capture_output=True,check=True)
except FileNotFoundError:
    print('NOT RUN: node is required for the optional independent cross-runtime check');raise SystemExit(3)
out=json.loads(run.stdout);assertions=0;max_error=0.
for values,actual in zip(words,out['words'],strict=True):
    expected=asa_word(*values)
    for x,y in zip((expected.asa,expected.na,expected.hits,expected.output),actual):
        assertions+=1;assert x==y
for values,actual in zip(angles,out['angles'],strict=True):
    dr,dp,axis,profile=values
    expected=observation(dr,dp,axis,profile)
    assertions+=1;assert expected['status']==actual['status']
    if actual['status']=='defined':
        for name,other in [('beta','beta'),('residual_raw','e')]:
            error=abs(expected[name]-actual[other]);max_error=max(max_error,error)
            assertions+=1;assert error<1e-12
report={'status':'passed','word_cases':len(words),'angle_cases':len(angles),'comparisons':assertions,
        'maximum_absolute_angle_difference_rad':max_error,'angle_tolerance_rad':1e-12,
        'node':subprocess.check_output(['node','--version'],text=True).strip(),
        'scope':'independent JS per-bit word oracle and angular formulas versus Python implementation'}
(ROOT/'results/cross_runtime.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
