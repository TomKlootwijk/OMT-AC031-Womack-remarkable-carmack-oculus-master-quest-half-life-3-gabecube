#!/bin/sh
set -eu
cd "$(dirname "$0")/../docs"
mkdir -p .build
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=.build master_361.tex
cp .build/master_361.pdf ../aTOMos_v3.6.1_Total_Integrated_Engine_Tom_Klootwijk.pdf
