#!/usr/bin/env python3
"""Generate the declared local fixture and its result without hardware defaults."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from atomos.engine import Engine
from atomos.records import genesis, digest, load_json


def write(name, value):
    (ROOT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    profile = {
        'schema': 'aTOMos-profile-1', 'engine_version': '3.6.1',
        'profile_id': 'local-mathematical-reference/1', 'profile_role': 'authored_test_fixture',
        'parent_profile': 'foundational-substrate/1',
        'parent_sha256': digest(load_json(ROOT/'profiles/foundation.json'), b'aTOMos:substrate:3.6.1\0'),
        'author': {'name': 'Tom Klootwijk', 'identifier': 'NL200678942', 'date': '10-07-1990'},
        'dictionary': {'id': 'fixture-2x40-v1', 'rows': 2, 'angles': 40,
                       'ordering': 'logical_row_major_words', 'frame': 'log_tangent'},
        'execution': {'model': 'local_preprocessed_words/1', 'fringe_mode': 'record',
                      'otan2_profile': 'source_ratio', 'jk_policy': 'explicit_events'},
        'masks': {'asa': [15, 255, 511, 255], 'na': [14, 255, 511, 255],
                  'boundary': [0, 128, 256, 0], 'fringe': [6, 255, 511, 255]},
        'transfer': {'kind': 'index_scale/1', 'h_rho': 0.125, 'h_phi': 0.0625,
                     'rho_unit': 'ln_ratio', 'phase_unit': 'rad', 'origin': 'authored_test_fixture'},
        'B_profile': {'kind': 'constant_log_field_fixture', 'state': ['rho', 'phi'],
                      'rate': [0.25, 0.5], 'time_unit': 'test_tick',
                      'purpose': 'standalone RK4 conformance example; not an antenna medium'},
        'eigenmatrix': {'kind': 'test_matrix', 'matrix': [[2, 0], [0, 1]],
                        'selected_vector': [1, 0], 'selected_value': 2,
                        'purpose': 'eigenpair identity fixture, not beamforming coefficients'},
        'projection': {'kind': 'identity_2d', 'input_dimension': 2, 'output_dimension': 2},
        'sampling': {'kind': 'provided_records', 'period_ns': 125000000,
                     'clock_id': 'fixture-clock', 'clock_status': 'synthetic'},
        'hardware': {'kind': 'not_bound', 'medium': 'not_selected', 'raw_wave_input': False},
        'initial_q': 0
    }
    write('profiles/local_reference.json', profile)
    engine = Engine(profile)
    header = {'schema': 'aTOMos-batch-1', 'profile_sha256': engine.profile_digest,
              'epoch': 0, 'batch_id': 'fixture-batch-0000', 'clock_id': 'fixture-clock',
              'frame_id': 'log_tangent', 'dictionary_id': 'fixture-2x40-v1',
              'start_ns': 0, 'end_ns': 125000000}
    records = []
    for i, x in enumerate([15, 165, 257, 85]):
        records.append({'word': i, 'occupancy': x, 'source_label': f'fixture-word-{i}',
            'batch_id': header['batch_id'], 'clock_id': header['clock_id'], 'frame_id': header['frame_id'],
            'profile_sha256': engine.profile_digest, 'timestamp_ns': i * 1000000,
            'alignment': {'status': 'unspecified'}, 'sweep_limit': {'status': 'unspecified'},
            'active_fringe': {'status': 'unspecified'}, 'blend_bits': [1, 0, 1],
            'orientation': {'kind': 'index_delta', 'delta_i': 4, 'delta_j': 8, 'axis_angle': 0.0}})
    batch = {**header, 'records': records,
             'jk_events': [{'timestamp_ns': 10000000, 'j': 1, 'k': 0}]}
    write('examples/coherent_batch.json', batch)
    result = engine.process(batch)
    write('examples/expected_epoch.json', result)
    write('examples/genesis.json', genesis(['author-symbol', 'asa-symbol']))
    print('Generated fixture profile, batch, epoch and symbolic genesis')


if __name__ == '__main__':
    main()
