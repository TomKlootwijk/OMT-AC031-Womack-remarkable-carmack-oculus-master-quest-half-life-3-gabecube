#!/usr/bin/env python3
"""Verify the unsigned delivery manifest; no network or authentication required."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
count=0
try:
    for line in (root/'SHA256SUMS.txt').read_text().splitlines():
        expected,name=line.split('  ',1)
        path=(root/name).resolve()
        if not path.is_relative_to(root) or not path.is_file() or len(expected)!=64:
            raise ValueError(f'missing/invalid manifest path: {name}')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            raise ValueError(f'changed file: {name}')
        count+=1
except (ValueError,OSError) as exc:
    print(f'FAIL: {exc}');raise SystemExit(1)
print(f'PASS: {count} delivered file hashes match')
