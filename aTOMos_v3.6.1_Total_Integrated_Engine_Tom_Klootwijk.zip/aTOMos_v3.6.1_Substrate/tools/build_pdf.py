#!/usr/bin/env python3
"""Cross-platform LaTeX build of the included complete master specification."""
from pathlib import Path
import shutil
import subprocess
ROOT=Path(__file__).resolve().parents[1]
if not shutil.which('latexmk'):
    raise SystemExit('latexmk is required only to rebuild the PDF; engine execution does not need it')
work=ROOT/'docs/.build';work.mkdir(exist_ok=True)
subprocess.run(['latexmk','-pdf','-interaction=nonstopmode','-halt-on-error',
                '-outdir=.build','master_361.tex'],cwd=ROOT/'docs',check=True)
target=ROOT/'aTOMos_v3.6.1_Total_Integrated_Engine_Tom_Klootwijk.pdf'
shutil.copy2(work/'master_361.pdf',target)
print(target)
