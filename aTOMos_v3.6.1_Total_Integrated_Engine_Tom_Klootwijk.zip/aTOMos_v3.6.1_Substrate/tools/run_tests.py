#!/usr/bin/env python3
"""Run the local blue-team and mathematical tests; record actual outcomes."""
from pathlib import Path
import json
import platform
import sys
import time
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
start=time.perf_counter()
with (ROOT/'results/tests.txt').open('w',encoding='utf-8') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
report={'engine_version':'3.6.1','status':'passed' if result.wasSuccessful() else 'failed',
        'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skipped':len(result.skipped),'python':platform.python_version(),
        'duration_seconds':time.perf_counter()-start,
        'scope':'Python local word-epoch reference, profile coherence, OTAN2, invariants, finite math and replay integrity',
        'hardware_acquisition':'not_implemented','gpu_execution':'not_run',
        'actual_propagation_profile':'not_supplied_by_attachment',
        'physical_feedback_policy':'not_supplied_by_attachment'}
(ROOT/'results/validation_status.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
