'use strict';
// Independent JS oracle for the published local mathematical primitives.
const fs=require('node:fs');
const input=JSON.parse(fs.readFileSync(0,'utf8'));
function wrap(x,p=2*Math.PI){x%=p;if(x>=p/2)x-=p;if(x< -p/2)x+=p;return Object.is(x,-0)?0:x;}
function wordOracle(v){
 const [x,a,n,b,valid,fringe]=v;let aa=0,nn=0,h=0;
 for(let i=0;i<32;i++){
  if(((x>>>i)&1)&&((a>>>i)&1)&&((valid>>>i)&1)&&((fringe>>>i)&1)){
   aa=(aa|((1<<i)>>>0))>>>0;
   if((n>>>i)&1){nn=(nn|((1<<i)>>>0))>>>0;if((b>>>i)&1)h++;}
  }
 }
 return [aa,nn,h,h?0:nn];
}
function angle(v){
 const [dr,dp,axis,profile]=v;
 if(dr===0&&dp===0)return {status:'zero_increment',beta:null,e:null};
 if(profile==='source_ratio'&&dr===0)return {status:'ratio_undefined',beta:null,e:null};
 const beta=profile==='source_ratio'?Math.atan(dp/dr):wrap(Math.atan2(dp,dr));
 return {status:'defined',beta,e:beta-axis};
}
console.log(JSON.stringify({words:input.words.map(wordOracle),angles:input.angles.map(angle)}));
