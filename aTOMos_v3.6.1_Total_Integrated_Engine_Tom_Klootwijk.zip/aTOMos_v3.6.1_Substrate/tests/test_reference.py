from __future__ import annotations
from copy import deepcopy
import json
import math
from pathlib import Path
import random
import tempfile
import unittest
from atomos.core import asa_word, bit, word, blend, jk, event_pair, shift_merge, child_id, facet_union, U32
from atomos.geometry import Shape, address, decode, morton3, chart, calibrate, klein, rk4
from atomos.orientation import otan2, observation, invariant_bank, endpoint_increment, wrap
from atomos.records import canonical, digest, genesis, event_head, verify_events, load_json
from atomos.engine import Engine
from atomos.tape import TapeMachine
ROOT = Path(__file__).resolve().parents[1]


def oracle(x, a, n, b, v, f):
    a_bits = {i for i in range(32) if (x >> i)&(a >> i)&(v >> i)&(f >> i)&1}
    n_bits = {i for i in a_bits if (n >> i)&1}
    h = sum((b >> i)&1 for i in n_bits)
    return sum(1<<i for i in a_bits), sum(1<<i for i in n_bits), h, 0 if h else sum(1<<i for i in n_bits)


class CoreTests(unittest.TestCase):
    def test_word_domain(self):
        for value in (-1, 1<<32, True, 1.0, '1'):
            with self.assertRaises(ValueError): word(value)
    def test_bit_domain(self):
        for value in (-1, 2, True, .5):
            with self.assertRaises(ValueError): bit(value)
    def test_population_count_full16(self):
        for i in range(65536):
            self.assertEqual(asa_word(i,U32,U32,U32).hits, bin(i).count('1'))
    def test_independent_word_oracle(self):
        rng=random.Random(361)
        for _ in range(3000):
            x,a,n,b,v,f=[rng.getrandbits(32) for _ in range(6)]
            got=asa_word(x,a,n,b,v,f)
            self.assertEqual((got.asa,got.na,got.hits,got.output),oracle(x,a,n,b,v,f))
    def test_whole_word_not_clearing(self):
        self.assertEqual(asa_word(255,U32,U32,128).output,0)
    def test_high_bit_intersection(self):
        self.assertEqual(asa_word(1<<31,U32,U32,1<<31).hits,1)
    def test_neutral_fringe(self):
        for x in range(128):
            self.assertEqual(asa_word(x,127,126,64,127),asa_word(x,127,126,64,127,127))
    def test_final_idempotence(self):
        rng=random.Random(31)
        for _ in range(1000):
            x,a,n,b,v=[rng.getrandbits(32) for _ in range(5)]
            y=asa_word(x,a,n,b,v).output
            self.assertEqual(asa_word(y,a,n,b,v).output,y)
    def test_nonmonotone_counterexample(self):
        self.assertEqual(asa_word(3,3,3,2,3).output,0)
        self.assertEqual(asa_word(3,3,3,2,3,1).output,1)
    def test_blend_all_bits(self):
        for n in (0,1):
            for a in (0,1):
                for b in (0,1): self.assertEqual(blend(n,a,b),(n+a+b)%2)
    def test_jk_table(self):
        for q in (0,1):
            for name,want in [('hold',q),('set',1),('reset',0),('toggle',1-q)]:
                self.assertEqual(jk(q,*event_pair(name)),want)
    def test_merge_variants(self):
        self.assertEqual(shift_merge(5,0,4,'xor'),8)
        self.assertEqual(shift_merge(5,0,4,'or'),10)
    def test_source_zero_guard(self):
        self.assertEqual(shift_merge(0,15,4),0)
        self.assertEqual(shift_merge(0,15,4,zero_absorbing=False),15)
    def test_lineage_unique(self):
        current=[1]
        for _ in range(8):
            nxt=[child_id(x,s) for x in current for s in (0,1)]
            self.assertEqual(len(set(nxt)),len(nxt))
            self.assertEqual([x>>1 for x in nxt], [p for p in current for _ in (0,1)])
            current=nxt
    def test_lineage_overflow(self):
        with self.assertRaises(OverflowError): child_id(1<<63,0)
    def test_union_idempotent(self):
        self.assertEqual(facet_union([3,5,3]),7)


class GeometryTests(unittest.TestCase):
    def test_morton_tile(self):
        self.assertEqual({morton3(r,w) for r in range(8) for w in range(8)},set(range(64)))
        self.assertEqual(morton3(1,0),1);self.assertEqual(morton3(0,1),2)
    def test_padded_roundtrip(self):
        for rows,angles in [(1,1),(17,257),(16,512)]:
            s=Shape(rows,angles)
            for layout in ('linear','morton8'):
                for i in range(s.padded_rows*s.padded_words):
                    self.assertEqual(address(s,*decode(s,i,layout),layout),i)
    def test_tails(self):
        for a in range(1,100):
            s=Shape(1,a)
            self.assertEqual(s.valid(s.words-1).bit_count(),a%32 or 32)
    def test_log_ratio(self):
        self.assertAlmostEqual(chart(4,.2,2)[0],math.log(2))
        with self.assertRaises(ValueError):chart(0,0)
    def test_calibrated_indices(self):
        self.assertEqual(calibrate(4,8,.125,.0625),(.5,.5))
        self.assertEqual(calibrate(8,16,.0625,.03125),(.5,.5))
    def test_klein_negative_seam(self):
        u,v,sign=klein(.2,-.25)
        self.assertAlmostEqual(u,.8);self.assertAlmostEqual(v,.75);self.assertEqual(sign,-1)
    def test_rk4_constant(self):
        result=rk4(lambda t,y:(.25,.5),0,(1,2),.125)
        self.assertEqual(result,(1.03125,2.0625))
    def test_rk4_convergence(self):
        def solve(h):
            y=(1.,);t=0
            for _ in range(round(1/h)):
                y=rk4(lambda t,z:z,t,y,h);t+=h
            return abs(y[0]-math.e)
        self.assertGreater(solve(.1)/solve(.05),14)
    def test_matrix_fixture_identity(self):
        p=load_json(ROOT/'profiles/local_reference.json')['eigenmatrix']
        a,v,lam=p['matrix'],p['selected_vector'],p['selected_value']
        self.assertEqual([sum(x*y for x,y in zip(row,v)) for row in a],[lam*x for x in v])
    def test_rk4_dimension(self):
        with self.assertRaises(ValueError):rk4(lambda t,y:(1,),0,(1,2),.1)


class OrientationTests(unittest.TestCase):
    def test_literal_order(self):
        self.assertAlmostEqual(otan2(1,2)['value'],math.atan(.5))
    def test_literal_reversal(self):
        self.assertEqual(otan2(1,1),otan2(-1,-1))
    def test_directed_quadrants(self):
        self.assertAlmostEqual(otan2(1,-1,'directed_completion_1')['value'],3*math.pi/4)
    def test_zero_and_denominator(self):
        self.assertEqual(otan2(0,0)['status'],'zero_increment')
        self.assertEqual(otan2(1,0)['status'],'ratio_undefined')
        self.assertEqual(otan2(0,0,'directed_completion_1')['status'],'zero_increment')
    def test_no_bearing_inference(self):
        # The same local increment can begin at different absolute phase origins.
        a=observation(.5,.5,0);b=observation(.5,.5,0)
        self.assertEqual(a,b)
        self.assertNotEqual(0.,math.pi/2)
    def test_absent_axis(self):
        o=observation(.5,.5,None)
        self.assertEqual(o['status'],'axis_unspecified');self.assertIsNotNone(o['beta'])
        self.assertIsNone(o['residual_raw'])
    def test_raw_residual_retained(self):
        o=observation(1,1,4)
        self.assertLess(o['residual_raw'],-math.pi);self.assertGreater(o['residual_principal'],0)
    def test_nonfinite_status(self):
        self.assertEqual(otan2(math.nan,1)['status'],'nonfinite_input')
        self.assertEqual(otan2(True,1)['status'],'nonfinite_input')
    def test_numeric_range(self):
        self.assertEqual(otan2(1e308,1e-308)['status'],'numerical_range')
        self.assertEqual(otan2(1e-308,1e308)['status'],'numerical_range')
    def test_phase_seam_policy(self):
        a,b=math.radians(359),math.radians(1)
        self.assertAlmostEqual(endpoint_increment(a,b,'principal_difference')['value'],math.radians(2))
        self.assertAlmostEqual(endpoint_increment(a,b,'known_turns',0)['value'],math.radians(-358))
        self.assertEqual(endpoint_increment(a,b,'unknown')['status'],'turn_information_unspecified')
    def test_bank(self):
        self.assertTrue(all(c['status']=='PASS' for c in invariant_bank(.5,.5,.25,interval=.125).values()))
    def test_random_invariants(self):
        rng=random.Random(2026)
        for _ in range(500):
            dr=rng.choice((-1,1))*rng.uniform(.1,3);dp=rng.uniform(-3,3)
            for profile in ('source_ratio','directed_completion_1'):
                bank=invariant_bank(dr,dp,rng.uniform(-2,2),profile,interval=.125)
                self.assertTrue(all(c['status']=='PASS' for c in bank.values()),bank)
    def test_invalid_interval_local(self):
        bank=invariant_bank(.5,.5,0,interval=0)
        self.assertEqual(bank['W']['status'],'UNDEFINED')
        self.assertEqual(bank['R']['status'],'PASS')
    def test_frame_line_class(self):
        bank=invariant_bank(1,0,0,rotation=3*math.pi/4)
        self.assertEqual(bank['F']['status'],'PASS')
    def test_axis_covariance(self):
        a=observation(.5,.5,.1);b=observation(.5,.5,.3)
        self.assertAlmostEqual(b['residual_raw'],a['residual_raw']-.2)


class RecordTests(unittest.TestCase):
    def test_float_type_not_dictionary_collision(self):
        self.assertNotEqual(canonical(1.0),canonical({'float64':(1.).hex()}))
        self.assertNotEqual(canonical(1),canonical(1.0))
    def test_canonical_order(self):
        self.assertEqual(canonical({'b':1,'a':2}),canonical({'a':2,'b':1}))
    def test_nonfinite_canonical(self):
        with self.assertRaises(ValueError):canonical({'bad':math.nan})
    def test_genesis_normalized_set(self):
        self.assertEqual(genesis(['a','café','a']),genesis(['cafe\u0301','a']))
        self.assertEqual(len(genesis(['a'])['sha256']),64)
    def test_duplicates_rejected_in_json(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'x.json';p.write_text('{"a":1,"a":2}')
            with self.assertRaises(ValueError):load_json(p)
    def test_data_is_not_executed(self):
        self.assertEqual(digest({'text':'__import__("os").system("bad")'}),digest({'text':'__import__("os").system("bad")'}))


class EpochTests(unittest.TestCase):
    def setUp(self):
        self.profile=load_json(ROOT/'profiles/local_reference.json')
        self.batch=load_json(ROOT/'examples/coherent_batch.json')
        self.engine=Engine(self.profile)
    def reject(self, mutate):
        original=self.engine.state;history=self.engine.events
        bad=deepcopy(self.batch);mutate(bad)
        with self.assertRaises((ValueError,KeyError,TypeError)):self.engine.process(bad)
        self.assertEqual(self.engine.state,original);self.assertEqual(self.engine.events,history)
        # A rejected input is not a permanent lockout: the original valid epoch still runs.
        self.engine.process(self.batch)
        self.assertEqual(self.engine.state.epoch,1)
    def test_worked_epoch(self):
        r=self.engine.process(self.batch)
        self.assertEqual([x['core']['output'] for x in r['record']['records']],[14,0,0,85])
        self.assertEqual(self.engine.state.q,1)
    def test_golden_record(self):
        self.assertEqual(self.engine.process(self.batch),load_json(ROOT/'examples/expected_epoch.json'))
    def test_mixed_clock(self):self.reject(lambda b:b['records'][0].update(clock_id='other'))
    def test_mixed_batch(self):self.reject(lambda b:b['records'][0].update(batch_id='other'))
    def test_stale_snapshot(self):self.reject(lambda b:b['records'][0].update(profile_sha256='0'*64))
    def test_end_time_exclusive(self):self.reject(lambda b:b['records'][0].update(timestamp_ns=b['end_ns']))
    def test_missing_word(self):self.reject(lambda b:b['records'].pop())
    def test_duplicate_word(self):self.reject(lambda b:b['records'][0].update(word=1))
    def test_nonzero_tail(self):self.reject(lambda b:b['records'][1].update(occupancy=1<<12))
    def test_bad_jk_type(self):self.reject(lambda b:b['jk_events'][0].update(j=True))
    def test_ordered_jk(self):
        b=deepcopy(self.batch)
        b['jk_events']=[{'timestamp_ns':1,'j':1,'k':0},{'timestamp_ns':2,'j':1,'k':1}]
        self.assertEqual(self.engine.process(b)['record']['jk']['after'],0)
    def test_input_order_canonical_output(self):
        b=deepcopy(self.batch);b['records'].reverse()
        a=self.engine.process(b)['record'];e=Engine(self.profile).process(self.batch)['record']
        self.assertEqual(a['records'],e['records'])
        self.assertNotEqual(a['input_sha256'],e['input_sha256'])
    def test_zero_denominator_not_core_reset(self):
        b=deepcopy(self.batch);b['records'][0]['orientation'].update(delta_i=0,delta_j=1)
        r=self.engine.process(b)['record']
        self.assertEqual(r['records'][0]['otan2']['status'],'ratio_undefined')
        self.assertEqual(r['records'][0]['core']['output'],14);self.assertEqual(r['jk']['after'],1)
    def test_axis_diagnostic_isolation(self):
        b=deepcopy(self.batch);b['records'][0]['orientation']['axis_angle']=1.2
        a=self.engine.process(b)['record'];e=Engine(self.profile).process(self.batch)['record']
        self.assertEqual(a['jk'],e['jk']);self.assertEqual(a['records'][0]['core'],e['records'][0]['core'])
        self.assertNotEqual(a['records'][0]['otan2']['residual_raw'],e['records'][0]['otan2']['residual_raw'])
    def test_profile_and_result_copy_isolation(self):
        self.profile['masks']['asa'][0]=0
        out=self.engine.process(self.batch);out['record']['records'][0]['core']['output']=999
        self.assertEqual(self.engine.state.words[0],14)
        self.assertEqual(self.engine.events[0]['record']['records'][0]['core']['output'],14)
    def test_sequence_and_hash_chain(self):
        self.engine.process(self.batch)
        b=deepcopy(self.batch);b.update(epoch=1,batch_id='fixture-batch-0001',start_ns=125000000,end_ns=250000000)
        for r in b['records']:
            r['batch_id']=b['batch_id'];r['timestamp_ns']+=125000000
        for e in b['jk_events']:e['timestamp_ns']+=125000000
        self.engine.process(b)
        self.assertTrue(verify_events(self.engine.events,self.engine.profile_digest))
        changed=self.engine.events;changed[0]['record']['records'][0]['core']['output']=999
        self.assertFalse(verify_events(changed,self.engine.profile_digest))
    def test_replay_rejected_without_state_change(self):
        self.engine.process(self.batch);old=self.engine.state
        with self.assertRaises(ValueError):self.engine.process(self.batch)
        self.assertEqual(old,self.engine.state)


class TapeTests(unittest.TestCase):
    def test_unary_example(self):
        m=TapeMachine({(0,1):(0,1,1),(0,0):(1,1,0)},cells={i:1 for i in range(8)})
        self.assertEqual(m.run(9),'halted');self.assertEqual(m.steps,9)
    def test_budget_is_not_halting(self):
        m=TapeMachine({(0,0):(0,0,1)})
        self.assertEqual(m.run(100),'budget_exhausted');self.assertEqual(m.q,0)
    def test_missing_rule(self):self.assertEqual(TapeMachine({}).step(),'missing_rule')
    def test_negative_addresses(self):
        m=TapeMachine({(0,0):(0,1,-1)})
        m.run(5);self.assertEqual(m.cells,dict.fromkeys([0,-1,-2,-3,-4],1))


if __name__=='__main__':unittest.main()
