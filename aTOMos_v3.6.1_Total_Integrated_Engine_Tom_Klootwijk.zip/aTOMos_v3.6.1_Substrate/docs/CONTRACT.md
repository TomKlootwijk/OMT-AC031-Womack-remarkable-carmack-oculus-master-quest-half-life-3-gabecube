# Normative reference contract — 3.6.1 / M2 / S1

## C01 Source and completion layers
D denotes the new 152-line Markdown attachment. A/B/O/F denote available prior
source PDFs. M1 denotes the previous conversational master definitions. N01–N10
in the PDF denote current consolidation decisions. Numerical fixture values are
not described as if supplied by D.

## C02 Core preservation
Input, ASA mask, NA mask, boundary mask and valid mask share one logical cell
mapping. Optional fringe is ANDed with the effective ASA mask. Record `a`, `n`,
`hits=popcount(n & boundary)` and `output=0 if hits else n`. Absorption applies to
the complete logical word, never per-bit clearing. Neutral fringe equals valid.

## C03 Coherence is a typed-domain property
One batch uses one profile digest, dictionary, clock and frame. Timestamps belong
to its half-open interval. No different snapshot or clock ID is silently relabelled.
This is record coherence, not a proof of coherent electromagnetic/acoustic phase.
Any actual clock conversion needs its own supplied calibration definition.

## C04 Evaluation order
Validate the complete required batch and freeze its snapshot. Resolve predicate
records before bit selection. Compute independent core, explicit sequential JK,
encoded blend and OTAN2/invariant results. Form the ordered record. Compute the
hash-chain extension. Publish the in-memory state and event record only after all
required stages succeed. No automatic observations-to-JK or observations-to-mask
mapping exists in the reference. Unavailable optional diagnostics remain statuses.

## C05 Temporal policy
The batch epoch must equal the next state epoch. A subsequent batch starts no
earlier than the previous committed end. JK events have times inside the batch
and nondecreasing order; same-time events preserve supplied list order. Record
arrival order is not confused with logical word order. Overlap/replay rejection
does not permanently disable the engine.

## C06 OTAN2
Default source_ratio: beta=atan(delta_phi/delta_rho), delta_rho nonzero.
Completion: principal atan2(delta_phi,delta_rho), explicitly tagged. Zero increment
has no direction in either profile. The source raw residual is beta-alpha, not
silently wrapped. Principal and line-class views have periods 2*pi and pi.
Inputs are radians and natural-log-radius increments in the log-tangent frame.
OTAN2 is not an upstream raw-wave direction-of-arrival estimator.

## C07 Transfer and profiles
The only executed transfer is `index_scale/1` or explicit supplied increments.
It converts preprocessed index changes to chart-unit changes. It is not an analog
receiver transfer function. The base source's hardware/physics slots remain
`declared_unbound`. The local profile binds its *test* field, matrix and values
and is separately labelled `authored_test_fixture`.

## C08 Canonical records
All values are recursively tagged. Floats use finite binary64 hex text; ints use
base-10 strings. Dictionaries sort string keys by UTF-8 bytes. Types are preserved
so that a dictionary pretending to be a float record does not collide. Both signs
of numerical zero are canonically +0.0. Domain strings and byte lengths distinguish
profile, identity and epoch hash roles. An unsigned chain is not authentication.

## C09 Editable deployment
No policy server, telemetry, license check or remote activation exists. Type,
finite-domain and coherence checks implement the equations and data contract.
No platform safeguards are disabled by this package. A local error leaves state
unchanged and does not persist a lockout flag. Files and profile values remain
editable by their holder.

## C10 Verification scope
Main tests use Python's standard library. Optional Node comparison is independent
of the Python word expressions. The full master PDF is a specification of the
whole architecture; code coverage is enumerated honestly. No raw wave, acquisition,
CUDA, real-time deadline, or physical-feedback validation is inferred from unit tests.
