# Flip exactly three consecutive bits, then halt.
states 4 halt 3
0 0 1 1 1
0 1 0 1 1
1 0 1 1 2
1 1 0 1 2
2 0 1 0 3
2 1 0 0 3
